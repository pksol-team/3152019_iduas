jQuery(document).ready(function($) {
	$("#demo .main-backgroud-slider").height($(window).height());
});